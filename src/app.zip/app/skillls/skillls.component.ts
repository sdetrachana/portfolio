import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-skillls',
  templateUrl: './skillls.component.html',
  styleUrls: ['./skillls.component.scss']
})
export class SkilllsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
