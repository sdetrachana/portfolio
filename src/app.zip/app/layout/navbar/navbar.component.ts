import { Component, OnInit, Input, SimpleChange, OnChanges } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  public allNavs:any;
  @Input() isInfo:boolean = false;
  @Input() isWarning:boolean = false;
  @Input() isDanger:boolean = false;
  @Input() isBlue:boolean = false;

  @Input() getsomeData:string = '';
  @Input() isList:boolean =false;

  @Input() allData:any;

  constructor() { }

  ngOnChanges(c:SimpleChange) { console.log("onchanges data is", this.allData); } 
  ngOnInit(): void {

    console.log('receiving all data' , this.allData );

    this.allNavs = [
      {id:'001',name:'introduction'},
      {id:'002',name:'summary'},
      {id:'003',name:'skillls'},
      {id:'004',name:'experience'},
      {id:'005',name:'contact'},
      {id:'006',name:'practical'},
    ]
  };

  // printAllData(){
  //   console.log('receiving all data' , this.allData );
  // }

}
