import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-practical',
  templateUrl: './practical.component.html',
  styleUrls: ['./practical.component.scss']
})
export class PracticalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
